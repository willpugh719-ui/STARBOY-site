const express = require('express');
const path = require('path');
const Stripe = require('stripe');

if (!process.env.STRIPE_SECRET_KEY) {
  console.error('Missing STRIPE_SECRET_KEY. Add it in your host settings under Environment.');
  process.exit(1);
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '10kb' }));

// Prices are in cents. Keep them the same as the prices shown on the site.
const PRODUCTS = {
  'Starboy Hoodie': 9500,
  'Starboy Tee': 4800,
  'Starboy Sweatpants': 7800,
};
const SIZES = ['S', 'M', 'L', 'XL'];

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.post('/create-checkout-session', async (req, res) => {
  try {
    const items = Array.isArray(req.body.items) ? req.body.items.slice(0, 20) : [];
    const line_items = items.map((i) => {
      const unit_amount = PRODUCTS[i.name];
      if (!unit_amount || !SIZES.includes(i.size)) throw new Error('Invalid item');
      const quantity = Math.min(Math.max(parseInt(i.q, 10) || 1, 1), 10);
      return {
        quantity,
        price_data: {
          currency: 'usd',
          unit_amount,
          product_data: { name: `${i.name} (Size ${i.size})` },
        },
      };
    });
    if (!line_items.length) return res.status(400).json({ error: 'Your cart is empty.' });

    const origin = `${req.protocol}://${req.get('host')}`;
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items,
      shipping_address_collection: { allowed_countries: ['US', 'CA', 'GB'] },
      success_url: `${origin}/?paid=1`,
      cancel_url: origin,
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err.message);
    res.status(400).json({ error: 'Could not start checkout.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Starboy is running on port ${port}`));
